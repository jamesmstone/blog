<!--                                                                                     
     #                                                                                        #     
      #                           ;                                                          #      
       #                          ;                                                         #       
        #                         ;                                                        #        
         #                        ;    ###   # #######    L###   ,###                     #         
          #                       ;   #   #  #    #   #  #    #  ,                       #          
           #                      ;       #  #    #   #  #    #                         #           
            #                     ;       #  #    #   #  ######  ##                    #            
             #                    ;   #####  #    #   #  #          #                 #             
              #                   ;   #   #  #    #   #  #                           #              
               #                  ;   #   #  #    #   G  ;          #               #
                #              ##;    # ##  #    #   #   :###   ###               #                
                 #                                                                #                 
                  #                                                              #                  
                   #                           iEDWDf                           #                   
                    #                     ################                     #                    
                     #                 ####              E###                 #                     
                      #             .###                    G##f             #                      
                       #           ##;                         ##,          #                       
                        #        ##f                            .##        #                        
                         #      ##                                ##;     #                         
                          #   j#t                                   ##   #                          
                           # ##                                      ## #                           
                            ##                                        ##                            
                           W##                                        ###                           
                          t#  #                                      #  ##                          
                          #    #                                    #    #t                         
                         #f     #                                  #      #                         
                        ##       #                                #       W#                        
                        #         #                              #         #f                       
                       #G          #                            #           #                       
                       #            #                          #            #W                      
                      #f             #                        #              #                      
                      #               #                      #               #t                     
                     ##                #                    #                ,#                     
                     #                  #                  #                  #                     
                     #                   #                #                   #f                    
                    W#                    #              #                    t#                    
                    #:                     #            #                      #                    
                    #                       #          #                       #                    
                    #                        #        #                        #                    
                    #                         #      #                         #f                   
                    #                          #    #                          ##                   
                   ;#                           #  #                           D#                   
                   f#                            ##                            f#                   
                   f#                            ##                            f#                   
                   t#                           #  #                           E#                   
                    #                          #    #                          ##                   
                    #                         #      #                         #f                   
                    #                        #        #                        #                    
                    #                       #          #                       #                    
                    #.                     #            #                      #                    
                    ##                    #              #                    i#                    
                     #                   #                #                   #L                    
                     #                  #                  #                  #                     
                     ##                #                    #                .#                     
                      #               #                      #               #j                     
                      #t             #                        #              #                      
                      .#            #                          #            ##                      
                       #f          #                            #           #                       
                        #         #                              #         #L                       
                        ##       #                                #       E#                        
                         #;     #                                  #      #                         
                          #    #                                    #    #L                         
                          G#  #                                      #  ##                          
                           ###                                        ###                           
                            ##                                        ##                            
                           # ##                                      ## #                           
                          #   E#,                                   ##   #                          
                         #      ##                                K#f     #                         
                        #        ##;                             ##        #                        
                       #           ##.                         ##f          #                       
                      #             t##G                    i##W             #                      
                     #                 ###E              f###;                #                     
                    #                    :################t                    #                    
                   #                          ,D####D;                          #                   
                  #                                                              #                  
                 #                                                                #                 
                #                                                                  #                
               #                                                                    #               
              #                  .####   #                                           #              
             #                   #       #                                            #             
            #                    ;       #                                             #            
           #                     #      ####   ####   #####    ####                     #           
          #                      .#t     #    #    #  #    #  #    #                     #          
         #                          ##   #   :     #  #    #  #    #                      #         
        #                             #  #   #     #  #    #  ######                       #        
       #                              #  #   #     #  #    #  #                             #       
      #                               W  #    :    #  #    #  #                              #      
     #                          ##   #   #    #   t:  #    #  #   #                           #     
    #                            ###t     #i   :##    #    #   ###:                            # 
 -->
 <!DOCTYPE html>
<html lang="en">
<head>
<!-- Meta, title, CSS, favicons, etc. -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php bloginfo('name'); ?> <?php wp_title(); ?></title>
<!-- Bootstrap core CSS -->
<link href="<?php bloginfo('stylesheet_directory'); ?>/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!-- My CSS -->
<link href='http://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
<!-- Load Lato Font -->
<link href="<?php bloginfo('stylesheet_directory'); ?>/style.css" rel="stylesheet" type="text/css">
<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
  <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
<![endif]-->
</head>
<body>
<a class="sr-only" href="#content">Skip to main content</a>
<!-- Events master nav -->
<header class="navbar navbar-inverse navbar-fixed-top bs-docs-nav" role="banner">
<div class="container">
	<div class="navbar-header">
		<button class="navbar-toggle" type="button" data-toggle="collapse" data-target=".bs-navbar-collapse">
		<span class="sr-only">Toggle navigation</span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		</button>
		<a href="<?php bloginfo('url')?>" class="navbar-brand"><?php bloginfo('name'); ?></a>
	</div>
	
  <?php
            wp_nav_menu( array(
                'menu'              => 'mainnav',
                'theme_location'    => 'primary-menu',
                'depth'             => 1,
                'container'         => 'nav',
                'container_class'   => 'collapse navbar-collapse bs-navbar-collapse',
                'menu_class'        => 'nav navbar-nav',
                'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
                'walker'            => new wp_bootstrap_navwalker()),
                'show_home'         => '1'
            );
        ?>
</div>
</header>
<!--
  <nav class="collapse navbar-collapse bs-navbar-collapse" role="navigation">
  <?php wp_nav_menu(array( 'menu' => 'mainnav', 'menu_class' => 'nav navbar-nav', 'container' => false, 'theme_location' => 'primary-menu', 'show_home' => '1')); ?>
  
  </nav>
  <ul class="nav navbar-nav">
    <li>
    <a href="http://blog.jamesstone.com.au">Blog</a>
    </li>
    <li class="active">
    <a href="/about">About</a>
    </li>
    <li>
  </ul>
  -->