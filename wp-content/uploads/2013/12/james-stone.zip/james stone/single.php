<?php get_header(); ?>
<!-- Docs page layout -->
<div class="header" id="content">
	<div class="container">
		<?php if ( ! have_posts() ) : ?>
			<h1>Not Found</h1>
			<p>Apologies, but no results were found for the requested archive. Perhaps searching will help find a related post</p>
		<?php endif; ?>
		<?php while ( have_posts() ) : the_post(); ?>
		<h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
		<p><?php the_date(); ?> <small><?php the_author(); ?> - <?php the_category(', '); ?></small>
					<small><?php edit_post_link('Edit', '<span class="comment-count">  ' , '</span>'); ?><span class="comment-count"><?php comments_popup_link('Leave a comment', '1 Comment', '% Comments'); ?></span></small></p>
		<div id="carbonads-container">
			<div class="carbonad">
				<div id="azcarbon">
				</div>
			</div>
		</div>
	</div>
</div>
<div class="container">
	<div class="row">
		<div class="col-md-9" role="main">


			<div class="bs-docs-section">
				
				<div class="page-header">
								

				</div>
				<p><?php if ( is_archive() || is_search() ) : // Only display excerpts for archives and search. ?>
					<?php the_excerpt(); ?>
			<?php else : ?>
					<?php the_content('Read More'); ?>
			<?php endif; ?>

			</p>
				</div>
				<?php endwhile; ?>
				<div class="bs-docs-section">
					<p>
			<?php if ( $wp_query->max_num_pages > 1 ) : ?>
				<?php next_posts_link('Older Posts'); ?>
				<?php previous_posts_link('Newer Posts'); ?>
			<?php else: ?>
					No other posts
			<?php endif; ?>																																	
				
			</p>
		</div>
			

			

			<?php comments_template( '', true ); ?>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>