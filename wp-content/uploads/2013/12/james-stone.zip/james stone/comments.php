<div class="bs-docs-section">
	<div class="page-header">
		<?php if ( have_comments() ) : ?>
		<h1><?php printf( _n( 'One Comment', '%1$s Comments', get_comments_number() ),number_format_i18n( get_comments_number() ) );
		?></h1>

		// Comment loop goes here

		<?php else: ?>
		<h1>No comments</h1>
		<?php endif; ?>
	</div>
	<p>
		<?php foreach ($comments as $comment) { ?>
		<div class="comment">
			<a name="comment-<?php comment_ID(); ?>"></a>
			<?php echo get_avatar( $comment->comment_author_email, $size = '40'); ?>
			<div class="comment-right">
				<span class="comment-author"><a href="<?php comment_author_url(); ?>"><?php comment_author(); ?></a></span> <span class="comment-date">on <?php comment_date(); ?></span>
				<p><?php echo $comment->comment_content; ?></p>
			</div>
			<div class="spacer"></div>
		</div><!-- comment -->
		<?php } ?>
	</p>
</div>
<div class="bs-docs-section">
	<div class="page-header">
		<?php if ( ! comments_open() ) : ?>
		<h1>Please Login.</h1>
		<?php else: ?>
		<h1>Leave a Comment</h1> 
		<a name="comments"></a>
	</div>
	<p>
		<form action="<?php bloginfo('url'); ?>/wp-comments-post.php" method="post" id="commentform"> 
				<input type='hidden' name='comment_post_ID' value='<?php echo $post->ID; ?>' id='comment_post_ID' /> 
				<input type="text" value="Name" name="author" onfocus="if(this.value == this.defaultValue) this.value = ''"><label>Name / Alias (required)</label><br /> 
				<input type="text" value="Email" name="email" onfocus="if(this.value == this.defaultValue) this.value = ''"><label>Email Address (required, not shown)</label><br /> 
				<input type="text" value="" name="url"><label>Website (optional)</label><br /> 
				<textarea rows="7" cols="60" name="comment"></textarea><br /> 
				<input type="submit" value="Add Your Comment" /> 
			</form>

		<?php endif; ?>
	</p>
</div>
